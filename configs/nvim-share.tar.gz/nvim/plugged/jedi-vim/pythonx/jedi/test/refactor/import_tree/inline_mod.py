inline_var = 5 + 3
