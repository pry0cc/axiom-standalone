from ..usages import usage_definition


def x():
    usage_definition()
