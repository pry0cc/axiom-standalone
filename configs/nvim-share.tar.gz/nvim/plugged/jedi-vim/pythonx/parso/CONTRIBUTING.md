We <3 Pull Requests! Three core things:

 1. If you are adding functionality or fixing a bug, please add a test!
 2. Add your name to AUTHORS.txt
 3. Use the PEP8 style guide.

 If you want to add methods to the parser tree, we will need to discuss this in
 an issue first.
